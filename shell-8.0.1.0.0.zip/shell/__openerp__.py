{
    'name': 'Shell command backport',
    'summary': 'Backport of the v9 shell CLI command.',
    'author': "Daniel Reis,Odoo Community Association (OCA)",
    'version': '8.0.1.0.0',
}
